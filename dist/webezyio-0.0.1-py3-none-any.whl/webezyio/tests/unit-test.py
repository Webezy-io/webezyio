def test_architect():
    pass

def test_builder():
    pass

def test_cli():
    pass
